System.register(['./glb-viewer-67004607.nomodule.js', './script-loader-eb805e1f.nomodule.js', './query-params-helper-d83ee85d.nomodule.js', './main-thread-to-worker-d8be741d.nomodule.js', './roomle-dependency-injection-581d40cc.nomodule.js', './scene-manager-7a1180ea.nomodule.js', './default-light-setting-05993e6d.nomodule.js'], (function () {
	'use strict';
	var GlbViewer;
	return {
		setters: [function (module) {
			GlbViewer = module.GlbViewer;
		}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: (function () {

			const glbViewer = new GlbViewer();
			glbViewer.boot();

		})
	};
}));
//# sourceMappingURL=glb-viewer-main.nomodule.js.map
