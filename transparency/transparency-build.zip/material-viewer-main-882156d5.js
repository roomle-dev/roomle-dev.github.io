import { MaterialViewer } from './material-viewer-a2a40db3.js';
import './script-loader-d6791558.js';
import './query-params-helper-f12b7599.js';
import './main-thread-to-worker-8a755a37.js';
import './roomle-dependency-injection-56c1d591.js';
import './scene-manager-2a6437e2.js';

const materialViewer = new MaterialViewer();
materialViewer.boot();
//# sourceMappingURL=material-viewer-main-882156d5.js.map
