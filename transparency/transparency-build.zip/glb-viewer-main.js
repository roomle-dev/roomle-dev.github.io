import { GlbViewer } from './glb-viewer-2434c9df.js';
import './script-loader-d6791558.js';
import './query-params-helper-f12b7599.js';
import './main-thread-to-worker-8a755a37.js';
import './roomle-dependency-injection-56c1d591.js';
import './scene-manager-2a6437e2.js';
import './default-light-setting-3bf50a43.js';

const glbViewer = new GlbViewer();
glbViewer.boot();
//# sourceMappingURL=glb-viewer-main.js.map
